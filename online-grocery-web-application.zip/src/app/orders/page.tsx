import Link from "next/link";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/session";
import { getOrdersByUser } from "@/lib/data";
import { formatCurrency, formatDate } from "@/lib/format";
import { StatusBadge } from "@/components/StatusBadge";
import { SuccessBanner } from "@/components/SuccessBanner";
import { PrintButton } from "@/components/PrintButton";
import { computeTotals } from "@/lib/commerce";

export const dynamic = "force-dynamic";

type SearchParams = Promise<{ success?: string }>;

const STATUS_STYLES: Record<string, string> = {
  pending: "bg-amber-100 text-amber-800",
  processing: "bg-sky-100 text-sky-800",
  shipped: "bg-indigo-100 text-indigo-800",
  delivered: "bg-emerald-100 text-emerald-800",
  cancelled: "bg-red-100 text-red-700",
};

export default async function OrdersPage({ searchParams }: { searchParams: SearchParams }) {
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/orders");

  const params = await searchParams;
  const successId = params.success ? Number(params.success) : NaN;
  const orders = await getOrdersByUser(user.id);

  // Separate the newly placed successful order for the highlighted invoice view
  const currentInvoiceOrder = !Number.isNaN(successId)
    ? orders.find((o) => o.id === successId)
    : null;

  const pastOrders = currentInvoiceOrder
    ? orders.filter((o) => o.id !== successId)
    : orders;

  return (
    <div className="space-y-8">
      {/* 1. Header (hidden on print) */}
      <div className="flex flex-wrap items-center justify-between gap-4 print:hidden">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">My Orders &amp; Invoices</h1>
          <p className="text-sm text-slate-500">
            Track deliveries, view past purchases, and download retail invoices.
          </p>
        </div>
        <Link
          href="/"
          className="rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700 transition hover:bg-slate-50"
        >
          ← Continue shopping
        </Link>
      </div>

      {/* 2. Success Banner (hidden on print) */}
      {currentInvoiceOrder && (
        <div className="print:hidden">
          <SuccessBanner orderId={successId} />
        </div>
      )}

      {/* 3. Highlighted Invoice (if just checked out) */}
      {currentInvoiceOrder && (
        <section className="only-print-invoice rounded-3xl border-2 border-emerald-500 bg-white shadow-md p-6 sm:p-8 space-y-6">
          <div className="flex flex-wrap items-start justify-between gap-4 border-b border-slate-200 pb-5">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-3xl">🛒</span>
                <span className="text-xl font-extrabold tracking-tight text-emerald-800">
                  Fresh<span className="text-emerald-600">Cart</span>
                </span>
              </div>
              <p className="mt-1 text-xs text-slate-400">FreshCart Grocery India Pvt Ltd</p>
              <p className="text-xs text-slate-400">GSTIN: 29AAFCC1024D1ZH</p>
            </div>
            <div className="text-right">
              <span className="rounded-full bg-emerald-100 px-3 py-1 text-xs font-bold text-emerald-800 uppercase tracking-wider print:hidden">
                New Order Placed
              </span>
              <h2 className="mt-2 text-xl font-bold text-slate-900">RETAIL INVOICE</h2>
              <p className="text-sm text-slate-500">Invoice No: #FC-{currentInvoiceOrder.id}</p>
              <p className="text-xs text-slate-400">Date: {formatDate(currentInvoiceOrder.createdAt)}</p>
            </div>
          </div>

          <div className="grid gap-6 sm:grid-cols-2 text-sm">
            <div>
              <h3 className="font-bold uppercase tracking-wider text-slate-400 text-xs">Customer details</h3>
              <p className="mt-1.5 font-bold text-slate-800">{currentInvoiceOrder.shippingName}</p>
              <p className="text-slate-600">{user.email}</p>
            </div>
            <div>
              <h3 className="font-bold uppercase tracking-wider text-slate-400 text-xs">Delivery Address</h3>
              <p className="mt-1.5 text-slate-700">{currentInvoiceOrder.shippingAddress}</p>
              <p className="text-slate-700">{currentInvoiceOrder.shippingCity} - {currentInvoiceOrder.shippingZip}</p>
              <p className="mt-1 text-xs font-medium text-slate-500">Mode: {currentInvoiceOrder.paymentMethod.toUpperCase()}</p>
            </div>
          </div>

          {/* Items Table */}
          <div className="overflow-x-auto border-t border-slate-100 pt-4">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-slate-200 text-xs uppercase tracking-wider text-slate-400">
                  <th className="py-2">Item</th>
                  <th className="py-2 text-right">Qty</th>
                  <th className="py-2 text-right">Price</th>
                  <th className="py-2 text-right">Total</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {currentInvoiceOrder.items.map((item) => (
                  <tr key={item.id}>
                    <td className="py-3">
                      <div className="flex items-center gap-2">
                        <span>{item.emoji}</span>
                        <span className="font-semibold text-slate-800">{item.name}</span>
                        <span className="text-xs text-slate-400">per {item.unit}</span>
                      </div>
                    </td>
                    <td className="py-3 text-right text-slate-700">{item.quantity}</td>
                    <td className="py-3 text-right text-slate-700">{formatCurrency(Number(item.price))}</td>
                    <td className="py-3 text-right font-semibold text-slate-900">
                      {formatCurrency(Number(item.price) * item.quantity)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Receipt Summary Breakdown */}
          {(() => {
            const subtotal = currentInvoiceOrder.items.reduce(
              (sum, i) => sum + Number(i.price) * i.quantity,
              0,
            );
            const { shipping, tax, total } = computeTotals(subtotal);

            return (
              <div className="flex flex-col items-end gap-1.5 border-t border-slate-200 pt-4 text-sm">
                <div className="flex justify-between w-64 text-slate-500">
                  <span>Subtotal:</span>
                  <span className="font-medium text-slate-900">{formatCurrency(subtotal)}</span>
                </div>
                <div className="flex justify-between w-64 text-slate-500">
                  <span>GST (5%):</span>
                  <span className="font-medium text-slate-900">{formatCurrency(tax)}</span>
                </div>
                <div className="flex justify-between w-64 text-slate-500">
                  <span>Delivery Charge:</span>
                  <span className="font-medium text-slate-900">
                    {shipping === 0 ? "FREE" : formatCurrency(shipping)}
                  </span>
                </div>
                <div className="flex justify-between w-64 border-t border-slate-200 pt-2 text-base font-bold text-slate-900">
                  <span>Grand Total:</span>
                  <span className="text-emerald-700">{formatCurrency(total)}</span>
                </div>
              </div>
            );
          })()}

          {/* Action buttons (hidden on print) */}
          <div className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-100 pt-5 print:hidden">
            <p className="text-xs text-slate-400">
              * This is a computer generated document. No physical signature is required.
            </p>
            <div className="flex items-center gap-3">
              <PrintButton />
              <Link
                href="/"
                className="rounded-xl border border-slate-300 px-4 py-2.5 text-sm font-semibold text-slate-600 transition hover:bg-slate-50"
              >
                Done
              </Link>
            </div>
          </div>
        </section>
      )}

      {/* 4. Past Orders Section */}
      <div className="space-y-4 hide-on-invoice-print">
        {currentInvoiceOrder && (
          <h2 className="text-lg font-bold text-slate-900 mt-8">Past Orders</h2>
        )}

        {pastOrders.length === 0 && !currentInvoiceOrder ? (
          <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-12 text-center">
            <p className="text-5xl">📦</p>
            <p className="mt-3 text-lg font-semibold text-slate-700">No orders yet</p>
            <p className="mt-1 text-sm text-slate-500">
              When you place an order, it will appear here.
            </p>
            <Link
              href="/"
              className="mt-4 inline-block rounded-xl bg-emerald-600 px-4 py-2 text-sm font-semibold text-white hover:bg-emerald-700"
            >
              Start shopping
            </Link>
          </div>
        ) : (
          <ul className="space-y-4">
            {pastOrders.map((order) => (
              <li
                key={order.id}
                className="overflow-hidden rounded-2xl border border-slate-200 bg-white"
              >
                <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 bg-slate-50/70 px-5 py-3">
                  <div className="flex items-center gap-4">
                    <div>
                      <p className="text-xs uppercase tracking-wide text-slate-400">Order</p>
                      <p className="font-bold text-slate-900">#{order.id}</p>
                    </div>
                    <div>
                      <p className="text-xs uppercase tracking-wide text-slate-400">Placed</p>
                      <p className="text-sm font-medium text-slate-700">{formatDate(order.createdAt)}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <StatusBadge status={order.status} styles={STATUS_STYLES} />
                    <p className="text-lg font-bold text-emerald-700">{formatCurrency(Number(order.total))}</p>
                    {/* Enable printing past orders too */}
                    <Link
                      href={`/orders?success=${order.id}`}
                      className="rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-semibold text-slate-600 hover:bg-slate-50 transition"
                    >
                      📄 View Invoice
                    </Link>
                  </div>
                </div>

                <ul className="divide-y divide-slate-100">
                  {order.items.map((item) => (
                    <li key={item.id} className="flex items-center gap-3 px-5 py-3 text-sm">
                      <span className="grid h-10 w-10 place-items-center rounded-lg bg-emerald-50 text-xl">{item.emoji}</span>
                      <span className="flex-1 font-medium text-slate-800">{item.name}</span>
                      <span className="text-slate-500">× {item.quantity}</span>
                      <span className="w-20 text-right font-medium text-slate-900">
                        {formatCurrency(Number(item.price) * item.quantity)}
                      </span>
                    </li>
                  ))}
                </ul>

                <div className="border-t border-slate-100 px-5 py-3 text-sm text-slate-500">
                  📮 Shipping to {order.shippingName}, {order.shippingAddress}, {order.shippingCity} - {order.shippingZip}
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
