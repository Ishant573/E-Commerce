"use client";

import Link from "next/link";
import { useCart } from "@/components/CartProvider";
import { formatCurrency } from "@/lib/format";
import { computeTotals, FREE_SHIPPING_THRESHOLD } from "@/lib/commerce";

export default function CartPage() {
  const { items, subtotal, count, setQuantity, remove, clear, hydrated } = useCart();

  if (!hydrated) {
    return <div className="h-64 animate-pulse rounded-2xl bg-white" />;
  }

  if (count === 0) {
    return (
      <div className="mx-auto max-w-lg rounded-2xl border border-dashed border-slate-300 bg-white p-12 text-center">
        <p className="text-6xl">🛒</p>
        <h1 className="mt-4 text-2xl font-bold text-slate-900">Your cart is empty</h1>
        <p className="mt-2 text-slate-500">
          Browse the catalog and add some fresh groceries.
        </p>
        <Link
          href="/"
          className="mt-6 inline-block rounded-xl bg-emerald-600 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-emerald-700"
        >
          Start shopping
        </Link>
      </div>
    );
  }

  const { shipping, tax, total } = computeTotals(subtotal);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-slate-900">Your cart</h1>
        <button
          type="button"
          onClick={clear}
          className="text-sm font-medium text-slate-500 transition hover:text-red-600"
        >
          Clear cart
        </button>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1fr_22rem]">
        {/* Items */}
        <ul className="divide-y divide-slate-100 overflow-hidden rounded-2xl border border-slate-200 bg-white">
          {items.map(({ product, quantity }) => (
            <li key={product.id} className="flex items-center gap-4 p-4">
              <div className="grid h-16 w-16 flex-shrink-0 place-items-center rounded-xl bg-gradient-to-br from-emerald-50 to-lime-50 text-3xl">
                {product.emoji}
              </div>
              <div className="min-w-0 flex-1">
                <Link
                  href={`/?category=${encodeURIComponent(product.category)}#catalog`}
                  className="font-semibold text-slate-900 hover:text-emerald-700"
                >
                  {product.name}
                </Link>
                <p className="text-sm text-slate-500">
                  {formatCurrency(product.price)} · per {product.unit}
                </p>
                {product.stock <= 0 && (
                  <p className="text-xs font-semibold text-red-600">
                    No longer in stock
                  </p>
                )}
              </div>

              <div className="flex items-center rounded-lg border border-slate-300">
                <button
                  type="button"
                  aria-label="Decrease quantity"
                  onClick={() => setQuantity(product.id, quantity - 1)}
                  className="grid h-8 w-8 place-items-center text-slate-600 hover:bg-slate-100"
                >
                  −
                </button>
                <input
                  type="number"
                  value={quantity}
                  min={0}
                  onChange={(e) =>
                    setQuantity(product.id, Math.max(0, Number(e.target.value) || 0))
                  }
                  className="h-8 w-10 border-x border-slate-300 text-center text-sm outline-none"
                />
                <button
                  type="button"
                  aria-label="Increase quantity"
                  onClick={() => setQuantity(product.id, quantity + 1)}
                  className="grid h-8 w-8 place-items-center text-slate-600 hover:bg-slate-100"
                >
                  +
                </button>
              </div>

              <div className="w-20 text-right font-semibold text-slate-900">
                {formatCurrency(product.price * quantity)}
              </div>
              <button
                type="button"
                onClick={() => remove(product.id)}
                aria-label={`Remove ${product.name}`}
                className="grid h-8 w-8 place-items-center rounded-lg text-slate-400 transition hover:bg-red-50 hover:text-red-600"
              >
                ✕
              </button>
            </li>
          ))}
        </ul>

        {/* Summary */}
        <aside className="h-fit rounded-2xl border border-slate-200 bg-white p-5">
          <h2 className="text-lg font-bold text-slate-900">Order summary</h2>
          <dl className="mt-4 space-y-2.5 text-sm">
            <div className="flex justify-between">
              <dt className="text-slate-500">Subtotal</dt>
              <dd className="font-medium text-slate-900">{formatCurrency(subtotal)}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-slate-500">Shipping</dt>
              <dd className="font-medium text-slate-900">
                {shipping === 0 ? "Free" : formatCurrency(shipping)}
              </dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-slate-500">GST (5%)</dt>
              <dd className="font-medium text-slate-900">{formatCurrency(tax)}</dd>
            </div>
            {shipping > 0 && (
              <p className="rounded-lg bg-amber-50 px-3 py-2 text-xs text-amber-800">
                Add {formatCurrency(FREE_SHIPPING_THRESHOLD - subtotal)} more for
                free shipping 🚚
              </p>
            )}
            <div className="flex justify-between border-t border-slate-200 pt-3 text-base">
              <dt className="font-bold text-slate-900">Total</dt>
              <dd className="font-bold text-emerald-700">{formatCurrency(total)}</dd>
            </div>
          </dl>
          <Link
            href="/checkout"
            className="mt-5 block w-full rounded-xl bg-emerald-600 px-4 py-3 text-center text-sm font-semibold text-white shadow-sm transition hover:bg-emerald-700"
          >
            Proceed to checkout
          </Link>
          <Link
            href="/"
            className="mt-2 block w-full rounded-xl px-4 py-2 text-center text-sm font-medium text-slate-600 transition hover:bg-slate-100"
          >
            Continue shopping
          </Link>
        </aside>
      </div>
    </div>
  );
}
