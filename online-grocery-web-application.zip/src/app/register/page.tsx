import { Suspense } from "react";
import { RegisterForm } from "@/components/auth/RegisterForm";

export const metadata = {
  title: "Sign up — FreshCart",
};

export default function RegisterPage() {
  return (
    <Suspense fallback={<AuthFallback />}>
      <RegisterForm />
    </Suspense>
  );
}

function AuthFallback() {
  return (
    <div className="mx-auto max-w-md">
      <div className="h-96 animate-pulse rounded-2xl bg-white shadow-sm" />
    </div>
  );
}
