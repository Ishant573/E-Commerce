import Link from "next/link";
import { db } from "@/db";
import { products, orders, orderItems, users, sessions } from "@/db/schema";
import { desc, asc, sql, eq, lte } from "drizzle-orm";
import { formatCurrency, formatDate } from "@/lib/format";
import { StatusBadge } from "@/components/StatusBadge";

export const dynamic = "force-dynamic";

const STATUS_STYLES: Record<string, string> = {
  pending: "bg-amber-100 text-amber-800",
  processing: "bg-sky-100 text-sky-800",
  shipped: "bg-indigo-100 text-indigo-800",
  delivered: "bg-emerald-100 text-emerald-800",
  cancelled: "bg-red-100 text-red-700",
};

export default async function AdminDashboardPage() {
  // Let's run raw PostgreSQL queries to query DB status and connection details
  const [
    productStats,
    orderStats,
    recentOrders,
    lowStock,
    popular,
    totalUsers,
    totalSessions,
    dbVersion,
  ] = await Promise.all([
    db
      .select({
        count: sql<number>`count(*)::int`,
        totalStock: sql<number>`coalesce(sum(${products.stock}), 0)::int`,
        inventoryValue: sql<number>`coalesce(sum(${products.stock} * ${products.price}), 0)::float8`,
      })
      .from(products),
    db
      .select({
        count: sql<number>`count(*)::int`,
        revenue: sql<number>`coalesce(sum(${orders.total}), 0)::float8`,
      })
      .from(orders),
    db.select().from(orders).orderBy(desc(orders.createdAt)).limit(5),
    db
      .select()
      .from(products)
      .where(lte(products.stock, 5))
      .orderBy(asc(products.stock))
      .limit(6),
    db
      .select({
        name: orderItems.name,
        emoji: orderItems.emoji,
        units: sql<number>`sum(${orderItems.quantity})::int`,
        revenue: sql<number>`sum(${orderItems.quantity} * ${orderItems.price})::float8`,
      })
      .from(orderItems)
      .groupBy(orderItems.productId, orderItems.name, orderItems.emoji)
      .orderBy(desc(sql`sum(${orderItems.quantity})`))
      .limit(5),
    db.select({ count: sql<number>`count(*)::int` }).from(users),
    db.select({ count: sql<number>`count(*)::int` }).from(sessions),
    db.execute(sql`SELECT version()`),
  ]);

  const p = productStats[0];
  const o = orderStats[0];
  const uCount = totalUsers[0]?.count ?? 0;
  const sCount = totalSessions[0]?.count ?? 0;
  const dbVerString = String(dbVersion.rows[0]?.version || "PostgreSQL").split(",")[0];

  const cards = [
    { label: "Total revenue", value: formatCurrency(o.revenue), icon: "💰", tone: "emerald" },
    { label: "Orders Placed", value: String(o.count), icon: "📦", tone: "sky" },
    { label: "Registered Users", value: String(uCount), icon: "👥", tone: "indigo" },
    { label: "Catalog Products", value: String(p.count), icon: "🥬", tone: "amber" },
  ];

  const toneMap: Record<string, string> = {
    emerald: "from-emerald-500 to-teal-500",
    sky: "from-sky-500 to-blue-500",
    amber: "from-amber-500 to-orange-500",
    indigo: "from-indigo-500 to-violet-500",
  };

  return (
    <div className="space-y-6">
      {/* Stat cards */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {cards.map((c) => (
          <div
            key={c.label}
            className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"
          >
            <div
              className={`mb-3 grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br ${toneMap[c.tone]} text-lg text-white`}
            >
              {c.icon}
            </div>
            <p className="text-2xl font-bold text-slate-900">{c.value}</p>
            <p className="text-sm text-slate-500">{c.label}</p>
          </div>
        ))}
      </div>

      {/* Backend Status Hub */}
      <section className="rounded-2xl border border-slate-200 bg-slate-900 text-slate-100 p-5 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div className="flex items-center gap-2.5">
            <span className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
            </span>
            <div>
              <h2 className="text-base font-bold text-white">Live Backend &amp; Database Monitor</h2>
              <p className="text-xs text-slate-400">Real-time stats from PostgreSQL via Drizzle ORM</p>
            </div>
          </div>
          <span className="rounded-md bg-emerald-500/10 px-2.5 py-1 text-xs font-semibold text-emerald-400 border border-emerald-500/20">
            Drizzle ORM: Connected
          </span>
        </div>

        <div className="mt-5 grid gap-4 sm:grid-cols-3 text-sm">
          <div className="rounded-xl bg-slate-950 p-4 border border-slate-800">
            <p className="text-xs text-slate-500 uppercase font-bold tracking-wider">Database engine</p>
            <p className="mt-1 font-semibold text-slate-200 truncate" title={dbVerString}>
              {dbVerString}
            </p>
            <p className="mt-2 text-xs text-emerald-400">Connection pool initialized</p>
          </div>
          <div className="rounded-xl bg-slate-950 p-4 border border-slate-800">
            <p className="text-xs text-slate-500 uppercase font-bold tracking-wider">Active auth sessions</p>
            <p className="mt-1 text-xl font-bold text-white">{sCount} Session tokens</p>
            <p className="mt-1 text-xs text-slate-400">Auto-expires after 365 days</p>
          </div>
          <div className="rounded-xl bg-slate-950 p-4 border border-slate-800">
            <p className="text-xs text-slate-500 uppercase font-bold tracking-wider">Inventory economics</p>
            <p className="mt-1 text-xl font-bold text-amber-400">{formatCurrency(p.inventoryValue)}</p>
            <p className="mt-1 text-xs text-slate-400">Across {p.totalStock} total item units</p>
          </div>
        </div>
      </section>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Recent orders */}
        <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-lg font-bold text-slate-900">Recent orders</h2>
            <Link
              href="/admin/orders"
              className="text-sm font-semibold text-emerald-700 hover:underline"
            >
              View all
            </Link>
          </div>
          {recentOrders.length === 0 ? (
            <p className="py-8 text-center text-sm text-slate-500">No orders yet.</p>
          ) : (
            <ul className="divide-y divide-slate-100">
              {recentOrders.map((order) => (
                <li key={order.id} className="flex items-center gap-3 py-3">
                  <div className="flex-1">
                    <p className="font-semibold text-slate-900">#{order.id}</p>
                    <p className="text-xs text-slate-500">
                      {formatDate(order.createdAt)}
                    </p>
                  </div>
                  <StatusBadge status={order.status} styles={STATUS_STYLES} />
                  <span className="w-20 text-right font-semibold text-emerald-700">
                    {formatCurrency(Number(order.total))}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </section>

        {/* Best sellers */}
        <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
          <h2 className="mb-4 text-lg font-bold text-slate-900">Best sellers</h2>
          {popular.length === 0 ? (
            <p className="py-8 text-center text-sm text-slate-500">No sales data yet.</p>
          ) : (
            <ul className="space-y-3">
              {popular.map((item, i) => (
                <li key={i} className="flex items-center gap-3">
                  <span className="grid h-9 w-9 place-items-center rounded-lg bg-emerald-50 text-xl">
                    {item.emoji}
                  </span>
                  <span className="flex-1 font-medium text-slate-800">
                    {item.name}
                  </span>
                  <span className="text-sm text-slate-500">{item.units} sold</span>
                  <span className="w-20 text-right text-sm font-semibold text-slate-900">
                    {formatCurrency(item.revenue)}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>

      {/* Low stock */}
      <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-bold text-slate-900">Low stock alerts</h2>
          <Link
            href="/admin/products"
            className="text-sm font-semibold text-emerald-700 hover:underline"
          >
            Manage products
          </Link>
        </div>
        {lowStock.length === 0 ? (
          <p className="py-6 text-center text-sm text-slate-500">
            All products are well stocked. 🎉
          </p>
        ) : (
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
            {lowStock.map((p) => (
              <div
                key={p.id}
                className={`rounded-xl border p-3 text-center ${
                  p.stock === 0
                    ? "border-red-200 bg-red-50"
                    : "border-amber-200 bg-amber-50"
                }`}
              >
                <p className="text-2xl">{p.emoji}</p>
                <p className="mt-1 truncate text-xs font-medium text-slate-700">
                  {p.name}
                </p>
                <p
                  className={`text-sm font-bold ${
                    p.stock === 0 ? "text-red-600" : "text-amber-700"
                  }`}
                >
                  {p.stock} left
                </p>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
