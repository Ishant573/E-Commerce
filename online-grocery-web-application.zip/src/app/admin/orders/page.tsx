import { getAllOrders } from "@/lib/data";
import { formatCurrency, formatDate } from "@/lib/format";
import { OrderStatusSelect } from "@/components/admin/OrderStatusSelect";

export const dynamic = "force-dynamic";

export default async function AdminOrdersPage() {
  const orders = await getAllOrders();

  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-xl font-bold text-slate-900">Orders</h2>
        <p className="text-sm text-slate-500">
          {orders.length} order{orders.length === 1 ? "" : "s"} placed
        </p>
      </div>

      {orders.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-12 text-center">
          <p className="text-5xl">📭</p>
          <p className="mt-3 text-lg font-semibold text-slate-700">No orders yet</p>
        </div>
      ) : (
        <div className="space-y-4">
          {orders.map((order) => (
            <div
              key={order.id}
              className="overflow-hidden rounded-2xl border border-slate-200 bg-white"
            >
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 bg-slate-50/70 px-5 py-3">
                <div className="flex flex-wrap items-center gap-x-5 gap-y-1">
                  <div>
                    <p className="text-xs uppercase tracking-wide text-slate-400">
                      Order
                    </p>
                    <p className="font-bold text-slate-900">#{order.id}</p>
                  </div>
                  <div>
                    <p className="text-xs uppercase tracking-wide text-slate-400">
                      Customer
                    </p>
                    <p className="text-sm font-medium text-slate-700">
                      {order.customer.name}{" "}
                      <span className="text-slate-400">
                        ({order.customer.email})
                      </span>
                    </p>
                  </div>
                  <div>
                    <p className="text-xs uppercase tracking-wide text-slate-400">
                      Placed
                    </p>
                    <p className="text-sm font-medium text-slate-700">
                      {formatDate(order.createdAt)}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <OrderStatusSelect orderId={order.id} status={order.status} />
                  <p className="text-lg font-bold text-emerald-700">
                    {formatCurrency(Number(order.total))}
                  </p>
                </div>
              </div>

              <ul className="divide-y divide-slate-100">
                {order.items.map((item) => (
                  <li
                    key={item.id}
                    className="flex items-center gap-3 px-5 py-3 text-sm"
                  >
                    <span className="grid h-9 w-9 place-items-center rounded-lg bg-emerald-50 text-xl">
                      {item.emoji}
                    </span>
                    <span className="flex-1 font-medium text-slate-800">
                      {item.name}
                    </span>
                    <span className="text-slate-500">× {item.quantity}</span>
                    <span className="w-20 text-right font-medium text-slate-900">
                      {formatCurrency(Number(item.price) * item.quantity)}
                    </span>
                  </li>
                ))}
              </ul>

              <div className="flex flex-wrap justify-between gap-2 border-t border-slate-100 px-5 py-3 text-xs text-slate-500">
                <span>
                  📮 {order.shippingName}, {order.shippingAddress},{" "}
                  {order.shippingCity} - {order.shippingZip}
                </span>
                <span className="font-medium text-slate-600">
                  Payment: {order.paymentMethod}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
