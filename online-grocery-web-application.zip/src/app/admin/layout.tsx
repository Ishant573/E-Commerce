import Link from "next/link";
import { redirect } from "next/navigation";
import type { ReactNode } from "react";
import { getCurrentUser } from "@/lib/session";

export const dynamic = "force-dynamic";

const NAV = [
  { href: "/admin", label: "Dashboard", icon: "📊", exact: true },
  { href: "/admin/products", label: "Products", icon: "🥬" },
  { href: "/admin/orders", label: "Orders", icon: "📦" },
];

export default async function AdminLayout({ children }: { children: ReactNode }) {
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/admin");

  if (user.role !== "admin") {
    return (
      <div className="mx-auto max-w-md rounded-2xl border border-amber-200 bg-amber-50 p-8 text-center">
        <p className="text-5xl">🔒</p>
        <h1 className="mt-4 text-xl font-bold text-amber-900">Access restricted</h1>
        <p className="mt-2 text-sm text-amber-800">
          Your account doesn&apos;t have admin privileges.
        </p>
        <Link
          href="/"
          className="mt-5 inline-block rounded-lg bg-amber-600 px-4 py-2 text-sm font-semibold text-white hover:bg-amber-700"
        >
          Back to store
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <span className="grid h-11 w-11 place-items-center rounded-2xl bg-emerald-600 text-2xl text-white">
          ⚙️
        </span>
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Admin panel</h1>
          <p className="text-sm text-slate-500">
            Manage products and orders, {user.name}.
          </p>
        </div>
      </div>

      <nav className="flex flex-wrap gap-2 border-b border-slate-200 pb-3">
        {NAV.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className="rounded-lg px-3 py-2 text-sm font-medium text-slate-600 transition hover:bg-emerald-50 hover:text-emerald-700"
          >
            <span className="mr-1.5">{item.icon}</span>
            {item.label}
          </Link>
        ))}
      </nav>

      {children}
    </div>
  );
}
