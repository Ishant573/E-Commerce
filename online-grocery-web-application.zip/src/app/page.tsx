import Link from "next/link";
import { getProducts, getCategories } from "@/lib/data";
import { ProductGrid } from "@/components/ProductCard";

export const dynamic = "force-dynamic";

type SearchParams = Promise<{ category?: string; q?: string }>;

export default async function HomePage({ searchParams }: { searchParams: SearchParams }) {
  const params = await searchParams;
  const category = params.category ?? "All";
  const q = params.q ?? "";

  const [products, categories] = await Promise.all([
    getProducts({ category, q }),
    getCategories(),
  ]);

  const tabs = ["All", ...categories];

  return (
    <div className="space-y-8">
      {/* Hero */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-700 via-emerald-600 to-teal-600 px-6 py-12 text-white shadow-lg sm:px-10 sm:py-14">
        <div className="relative z-10 max-w-2xl">
          <p className="text-sm font-semibold uppercase tracking-widest text-lime-200">
            Farm fresh • Delivered fast
          </p>
          <h1 className="mt-2 text-3xl font-extrabold leading-tight sm:text-4xl">
            Groceries delivered to your door
          </h1>
          <p className="mt-3 max-w-xl text-emerald-50/90">
            Browse hundreds of fresh products, build your cart, and check out in
            minutes. Quality you can taste, prices you&apos;ll love.
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <a
              href="#catalog"
              className="rounded-xl bg-white px-5 py-2.5 text-sm font-semibold text-emerald-800 shadow-sm transition hover:bg-emerald-50"
            >
              Start shopping
            </a>
            <Link
              href="/register"
              className="rounded-xl border border-white/40 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-white/10"
            >
              Create account
            </Link>
          </div>
        </div>
        <div className="pointer-events-none absolute -right-6 -top-6 text-[10rem] opacity-20 sm:text-[14rem]">
          🥬
        </div>
        <div className="pointer-events-none absolute bottom-2 right-24 text-7xl opacity-20">
          🍓
        </div>
      </section>

      {/* Catalog */}
      <section id="catalog" className="space-y-5">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="text-2xl font-bold text-slate-900">Shop groceries</h2>
            <p className="text-sm text-slate-500">
              {products.length} product{products.length === 1 ? "" : "s"} available
            </p>
          </div>

          <form method="get" action="/" className="flex items-center gap-2">
            <input type="hidden" name="category" value={category} />
            <div className="relative">
              <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">
                🔍
              </span>
              <input
                type="search"
                name="q"
                defaultValue={q}
                placeholder="Search products…"
                className="w-full rounded-xl border border-slate-300 bg-white py-2.5 pl-9 pr-3 text-sm outline-none transition focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 sm:w-64"
              />
            </div>
          </form>
        </div>

        {/* Category tabs */}
        <div className="flex flex-wrap gap-2">
          {tabs.map((tab) => {
            const isActive = tab === category;
            const href =
              tab === "All"
                ? q
                  ? `/?q=${encodeURIComponent(q)}#catalog`
                  : "/#catalog"
                : `/?category=${encodeURIComponent(tab)}${q ? `&q=${encodeURIComponent(q)}` : ""}#catalog`;
            return (
              <a
                key={tab}
                href={href}
                className={`rounded-full px-4 py-1.5 text-sm font-medium transition ${
                  isActive
                    ? "bg-emerald-600 text-white shadow-sm"
                    : "bg-white text-slate-600 ring-1 ring-slate-200 hover:bg-slate-100"
                }`}
              >
                {tab}
              </a>
            );
          })}
        </div>

        <ProductGrid products={products} />
      </section>
    </div>
  );
}
