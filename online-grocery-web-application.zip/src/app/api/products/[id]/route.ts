import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { products } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getCurrentUser } from "@/lib/session";

export const dynamic = "force-dynamic";

type ProductBody = {
  name?: string;
  description?: string;
  price?: number | string;
  emoji?: string;
  unit?: string;
  category?: string;
  stock?: number | string;
};

async function requireAdmin() {
  const user = await getCurrentUser();
  if (!user || user.role !== "admin") return null;
  return user;
}

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  if (!(await requireAdmin())) {
    return NextResponse.json({ error: "Admin access required" }, { status: 403 });
  }

  const { id: idStr } = await params;
  const id = Number(idStr);
  if (!Number.isFinite(id)) {
    return NextResponse.json({ error: "Invalid product id" }, { status: 400 });
  }

  let body: ProductBody;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  }

  const updates: Partial<typeof products.$inferInsert> = {};
  if (body.name !== undefined) updates.name = body.name.trim();
  if (body.category !== undefined) updates.category = body.category.trim();
  if (body.unit !== undefined) updates.unit = body.unit.trim();
  if (body.emoji !== undefined) updates.emoji = body.emoji.trim() || "🛒";
  if (body.description !== undefined)
    updates.description = body.description.trim() || null;
  if (body.price !== undefined) {
    const price = Number(body.price);
    if (!Number.isFinite(price) || price < 0) {
      return NextResponse.json({ error: "Price must be a valid number" }, { status: 400 });
    }
    updates.price = price.toFixed(2);
  }
  if (body.stock !== undefined) {
    updates.stock = Math.max(0, Math.floor(Number(body.stock) || 0));
  }

  const [updated] = await db
    .update(products)
    .set(updates)
    .where(eq(products.id, id))
    .returning({ id: products.id });

  if (!updated) {
    return NextResponse.json({ error: "Product not found" }, { status: 404 });
  }
  return NextResponse.json({ ok: true });
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  if (!(await requireAdmin())) {
    return NextResponse.json({ error: "Admin access required" }, { status: 403 });
  }

  const { id: idStr } = await params;
  const id = Number(idStr);
  if (!Number.isFinite(id)) {
    return NextResponse.json({ error: "Invalid product id" }, { status: 400 });
  }

  await db.delete(products).where(eq(products.id, id));
  return NextResponse.json({ ok: true });
}
