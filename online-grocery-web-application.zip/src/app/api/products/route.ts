import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { products } from "@/db/schema";
import { getCurrentUser } from "@/lib/session";

export const dynamic = "force-dynamic";

type ProductBody = {
  name?: string;
  description?: string;
  price?: number | string;
  emoji?: string;
  unit?: string;
  category?: string;
  stock?: number | string;
};

export async function POST(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user || user.role !== "admin") {
    return NextResponse.json({ error: "Admin access required" }, { status: 403 });
  }

  let body: ProductBody;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  }

  const name = body.name?.trim();
  const category = body.category?.trim();
  const price = Number(body.price);
  const stock = Math.max(0, Math.floor(Number(body.stock) || 0));

  if (!name || !category) {
    return NextResponse.json(
      { error: "Name and category are required" },
      { status: 400 },
    );
  }
  if (!Number.isFinite(price) || price < 0) {
    return NextResponse.json({ error: "Price must be a valid number" }, { status: 400 });
  }

  const [created] = await db
    .insert(products)
    .values({
      name,
      description: body.description?.trim() || null,
      price: price.toFixed(2),
      emoji: body.emoji?.trim() || "🛒",
      unit: body.unit?.trim() || "each",
      category,
      stock,
    })
    .returning({ id: products.id });

  return NextResponse.json({ ok: true, id: created.id });
}
