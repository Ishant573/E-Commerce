import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { orders, orderItems, products } from "@/db/schema";
import { eq, inArray } from "drizzle-orm";
import { getCurrentUser } from "@/lib/session";
import { formatCurrency } from "@/lib/format";
import { computeTotals } from "@/lib/commerce";

export const dynamic = "force-dynamic";

type Body = {
  items: { productId: number; quantity: number }[];
  shippingName: string;
  shippingAddress: string;
  shippingCity: string;
  shippingZip: string;
  paymentMethod?: string;
};

export async function POST(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: "You must be logged in to checkout" }, { status: 401 });
  }

  let body: Body;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  }

  const { items } = body;
  if (!Array.isArray(items) || items.length === 0) {
    return NextResponse.json({ error: "Your cart is empty" }, { status: 400 });
  }

  const cleanItems = items
    .map((i) => ({
      productId: Number(i.productId),
      quantity: Math.max(1, Math.floor(Number(i.quantity) || 0)),
    }))
    .filter((i) => Number.isFinite(i.productId) && i.productId > 0);

  if (cleanItems.length === 0) {
    return NextResponse.json({ error: "Your cart is empty" }, { status: 400 });
  }

  const shipping = {
    name: body.shippingName?.trim(),
    address: body.shippingAddress?.trim(),
    city: body.shippingCity?.trim(),
    zip: body.shippingZip?.trim(),
  };
  if (!shipping.name || !shipping.address || !shipping.city || !shipping.zip) {
    return NextResponse.json(
      { error: "Please complete all shipping fields" },
      { status: 400 },
    );
  }

  const ids = cleanItems.map((i) => i.productId);
  const productRows = await db
    .select()
    .from(products)
    .where(inArray(products.id, ids));

  const productMap = new Map(productRows.map((p) => [p.id, p]));
  for (const item of cleanItems) {
    if (!productMap.has(item.productId)) {
      return NextResponse.json(
        { error: "One of the items in your cart is no longer available" },
        { status: 400 },
      );
    }
  }

  // Validate stock
  for (const item of cleanItems) {
    const product = productMap.get(item.productId)!;
    if (item.quantity > product.stock) {
      return NextResponse.json(
        {
          error: `Only ${product.stock} × ${product.name} ${product.unit} left in stock`,
        },
        { status: 400 },
      );
    }
  }

  const subtotal = cleanItems.reduce(
    (sum, item) => sum + Number(productMap.get(item.productId)!.price) * item.quantity,
    0,
  );
  const { total } = computeTotals(subtotal);

  const paymentMethod = body.paymentMethod?.trim() || "card";

  try {
    const result = await db.transaction(async (tx) => {
      const [order] = await tx
        .insert(orders)
        .values({
          userId: user.id,
          total: total.toFixed(2),
          status: "pending",
          shippingName: shipping.name!,
          shippingAddress: shipping.address!,
          shippingCity: shipping.city!,
          shippingZip: shipping.zip!,
          paymentMethod,
        })
        .returning({ id: orders.id });

      await tx.insert(orderItems).values(
        cleanItems.map((item) => {
          const p = productMap.get(item.productId)!;
          return {
            orderId: order.id,
            productId: p.id,
            name: p.name,
            emoji: p.emoji,
            unit: p.unit,
            price: p.price,
            quantity: item.quantity,
          };
        }),
      );

      // Decrement stock
      for (const item of cleanItems) {
        const p = productMap.get(item.productId)!;
        await tx
          .update(products)
          .set({ stock: Math.max(0, p.stock - item.quantity) })
          .where(eq(products.id, p.id));
      }

      return order;
    });

    return NextResponse.json({
      ok: true,
      orderId: result.id,
      total: formatCurrency(total),
    });
  } catch (err) {
    console.error("Order creation failed", err);
    return NextResponse.json(
      { error: "Could not complete your order. Please try again." },
      { status: 500 },
    );
  }
}
