import { Suspense } from "react";
import { LoginForm } from "@/components/auth/LoginForm";

export const metadata = {
  title: "Sign in — FreshCart",
};

export default function LoginPage() {
  return (
    <Suspense fallback={<AuthFallback />}>
      <LoginForm />
    </Suspense>
  );
}

function AuthFallback() {
  return (
    <div className="mx-auto max-w-md">
      <div className="h-96 animate-pulse rounded-2xl bg-white shadow-sm" />
    </div>
  );
}
