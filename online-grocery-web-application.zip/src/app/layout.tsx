import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { CartProvider } from "@/components/CartProvider";
import { Header } from "@/components/Header";

export const metadata: Metadata = {
  title: "FreshCart — Online Grocery Store",
  description:
    "Shop fresh groceries online. Browse the catalog, fill your cart, and check out in minutes.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-slate-50 text-slate-900 antialiased">
        <CartProvider>
          <Header />
          <main className="mx-auto w-full max-w-7xl px-4 py-8 sm:px-6">
            {children}
          </main>
          <footer className="mt-12 border-t border-slate-200 bg-white">
            <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-2 px-4 py-6 text-sm text-slate-500 sm:flex-row sm:px-6">
              <p>
                🛒 <span className="font-semibold text-slate-700">FreshCart</span> —
                Fresh groceries delivered.
              </p>
              <p>Built with Next.js, Drizzle &amp; PostgreSQL.</p>
            </div>
          </footer>
        </CartProvider>
      </body>
    </html>
  );
}
