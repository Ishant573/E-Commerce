import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/session";
import { CheckoutForm } from "@/components/CheckoutForm";

export const dynamic = "force-dynamic";

export default async function CheckoutPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/checkout");

  return (
    <CheckoutForm
      user={{ name: user.name, email: user.email }}
    />
  );
}
