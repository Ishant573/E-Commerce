import { db } from "@/db";
import { products, orders, orderItems, users } from "@/db/schema";
import { and, desc, eq, ilike, or, asc, ne } from "drizzle-orm";
import type { Product } from "@/lib/types";

export function mapProduct(row: typeof products.$inferSelect): Product {
  return {
    id: row.id,
    name: row.name,
    description: row.description,
    price: Number(row.price),
    emoji: row.emoji,
    unit: row.unit,
    category: row.category,
    stock: row.stock,
  };
}

export async function getProducts(opts?: {
  category?: string;
  q?: string;
}): Promise<Product[]> {
  const conditions = [];
  if (opts?.category && opts.category !== "All") {
    conditions.push(eq(products.category, opts.category));
  }
  if (opts?.q && opts.q.trim()) {
    const term = `%${opts.q.trim()}%`;
    conditions.push(
      or(
        ilike(products.name, term),
        ilike(products.description, term),
      )!,
    );
  }

  const rows = await db
    .select()
    .from(products)
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(asc(products.category), asc(products.name));

  return rows.map(mapProduct);
}

export async function getProductById(id: number): Promise<Product | null> {
  const rows = await db.select().from(products).where(eq(products.id, id)).limit(1);
  return rows[0] ? mapProduct(rows[0]) : null;
}

export async function getCategories(): Promise<string[]> {
  const rows = await db
    .select({ category: products.category })
    .from(products)
    .where(ne(products.category, ""))
    .groupBy(products.category)
    .orderBy(asc(products.category));
  return rows.map((r) => r.category);
}

export async function getOrdersByUser(userId: number) {
  const all = await db
    .select()
    .from(orders)
    .where(eq(orders.userId, userId))
    .orderBy(desc(orders.createdAt));
  const itemRows = await db.select().from(orderItems);
  return all.map((o) => ({
    ...o,
    items: itemRows.filter((i) => i.orderId === o.id),
  }));
}

export async function getAllOrders() {
  const all = await db.select().from(orders).orderBy(desc(orders.createdAt));
  const itemRows = await db.select().from(orderItems);
  const usersById = new Map<number, { name: string; email: string }>();
  const userRows = await db
    .select({ id: users.id, name: users.name, email: users.email })
    .from(users);
  for (const u of userRows) usersById.set(u.id, u);
  return all.map((o) => ({
    ...o,
    items: itemRows.filter((i) => i.orderId === o.id),
    customer: usersById.get(o.userId) ?? { name: "Unknown", email: "" },
  }));
}

export type AdminOrder = Awaited<ReturnType<typeof getAllOrders>>[number];
