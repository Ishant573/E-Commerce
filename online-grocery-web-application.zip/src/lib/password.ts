import { scryptSync, randomBytes, timingSafeEqual } from "crypto";

const KEY_LENGTH = 64;

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, KEY_LENGTH).toString("hex");
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const [salt, key] = stored.split(":");
  if (!salt || !key) return false;
  try {
    const hashBuf = Buffer.from(scryptSync(password, salt, KEY_LENGTH));
    const keyBuf = Buffer.from(key, "hex");
    if (hashBuf.length !== keyBuf.length) return false;
    return timingSafeEqual(hashBuf, keyBuf);
  } catch {
    return false;
  }
}
