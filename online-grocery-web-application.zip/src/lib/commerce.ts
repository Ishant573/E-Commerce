// Commerce constants in Indian Rupees (₹).
// Shared so the cart and checkout always agree.
export const FREE_SHIPPING_THRESHOLD = 500; // ₹
export const SHIPPING_FEE = 49; // ₹
export const TAX_RATE = 0.05; // 5% GST

export function computeTotals(subtotal: number) {
  const shipping =
    subtotal >= FREE_SHIPPING_THRESHOLD || subtotal === 0 ? 0 : SHIPPING_FEE;
  const tax = +(subtotal * TAX_RATE).toFixed(2);
  const total = +(subtotal + shipping + tax).toFixed(2);
  return { shipping, tax, total };
}
