export type Product = {
  id: number;
  name: string;
  description: string | null;
  price: number;
  emoji: string;
  unit: string;
  category: string;
  stock: number;
};

export type CartLine = {
  product: Product;
  quantity: number;
};

export type CartItemInput = {
  productId: number;
  quantity: number;
};
