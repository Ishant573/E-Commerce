import Link from "next/link";
import { getCurrentUser } from "@/lib/session";
import { CartBadge } from "@/components/CartBadge";
import { LogoutButton } from "@/components/LogoutButton";

export async function Header() {
  const user = await getCurrentUser();

  return (
    <header className="sticky top-0 z-40 border-b border-emerald-900/40 bg-emerald-800/95 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-7xl items-center gap-4 px-4 sm:px-6">
        <Link href="/" className="flex items-center gap-2">
          <span className="text-2xl" aria-hidden>
            🛒
          </span>
          <span className="text-lg font-extrabold tracking-tight text-white">
            Fresh<span className="text-lime-300">Cart</span>
          </span>
        </Link>

        <nav className="ml-4 hidden items-center gap-1 text-sm font-medium text-emerald-50/90 sm:flex">
          <Link
            href="/"
            className="rounded-md px-3 py-2 transition hover:bg-white/10"
          >
            Shop
          </Link>
          {user && (
            <Link
              href="/orders"
              className="rounded-md px-3 py-2 transition hover:bg-white/10"
            >
              My Orders
            </Link>
          )}
          {user?.role === "admin" && (
            <Link
              href="/admin"
              className="rounded-md bg-white/10 px-3 py-2 text-lime-200 transition hover:bg-white/20"
            >
              Admin
            </Link>
          )}
        </nav>

        <div className="ml-auto flex items-center gap-3">
          <Link
            href="/cart"
            aria-label="Cart"
            className="relative grid h-10 w-10 place-items-center rounded-full text-white transition hover:bg-white/10"
          >
            <CartBadge />
          </Link>

          {user ? (
            <div className="flex items-center gap-3">
              <div className="hidden text-right sm:block">
                <p className="text-sm font-semibold leading-tight text-white">
                  {user.name}
                </p>
                <p className="text-[11px] uppercase tracking-wide text-lime-200/80">
                  {user.role}
                </p>
              </div>
              <LogoutButton />
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <Link
                href="/login"
                className="rounded-lg px-3 py-2 text-sm font-medium text-emerald-50 transition hover:bg-white/10"
              >
                Log in
              </Link>
              <Link
                href="/register"
                className="rounded-lg bg-lime-400 px-3 py-2 text-sm font-semibold text-emerald-950 shadow-sm transition hover:bg-lime-300"
              >
                Sign up
              </Link>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
