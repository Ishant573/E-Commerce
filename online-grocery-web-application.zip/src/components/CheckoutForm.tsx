"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useCart } from "@/components/CartProvider";
import { formatCurrency } from "@/lib/format";
import { computeTotals } from "@/lib/commerce";
import { Field, inputClass } from "@/components/auth/Auth";

export function CheckoutForm({ user }: { user: { name: string; email: string } }) {
  const router = useRouter();
  const { items, subtotal, count, clear, hydrated } = useCart();

  const [shippingName, setShippingName] = useState(user.name);
  const [shippingAddress, setShippingAddress] = useState("");
  const [shippingCity, setShippingCity] = useState("");
  const [shippingZip, setShippingZip] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("card");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Wizard active step state (1 = User Details / Shipping, 2 = Payment Options)
  const [activeStep, setActiveStep] = useState<1 | 2>(1);

  const { shipping, tax, total } = computeTotals(subtotal);

  function handleProceedToPayment() {
    setError(null);
    if (!shippingName.trim() || !shippingAddress.trim() || !shippingCity.trim() || !shippingZip.trim()) {
      setError("Please complete all shipping details to proceed.");
      return;
    }
    setActiveStep(2);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    if (activeStep === 1) {
      handleProceedToPayment();
      return;
    }

    setLoading(true);
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          items: items.map((i) => ({
            productId: i.product.id,
            quantity: i.quantity,
          })),
          shippingName,
          shippingAddress,
          shippingCity,
          shippingZip,
          paymentMethod,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Could not place your order");
        setLoading(false);
        return;
      }
      clear();
      router.push(`/orders?success=${data.orderId}`);
      router.refresh();
    } catch {
      setError("Something went wrong. Please try again.");
      setLoading(false);
    }
  }

  if (!hydrated) {
    return <div className="h-64 animate-pulse rounded-2xl bg-white" />;
  }

  if (count === 0) {
    return (
      <div className="mx-auto max-w-lg rounded-2xl border border-dashed border-slate-300 bg-white p-12 text-center">
        <p className="text-6xl">🧾</p>
        <h1 className="mt-4 text-2xl font-bold text-slate-900">
          Nothing to check out
        </h1>
        <p className="mt-2 text-slate-500">Your cart is empty.</p>
        <Link
          href="/"
          className="mt-6 inline-block rounded-xl bg-emerald-600 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-emerald-700"
        >
          Browse products
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Checkout Progress Stepper */}
      <div className="flex items-center gap-4 border-b border-slate-200 pb-4">
        <button
          type="button"
          onClick={() => setActiveStep(1)}
          className={`flex items-center gap-2 text-sm font-bold transition ${
            activeStep === 1 ? "text-emerald-700" : "text-slate-500 hover:text-slate-800"
          }`}
        >
          <span className={`grid h-6 w-6 place-items-center rounded-full text-xs text-white ${
            activeStep === 1 ? "bg-emerald-600" : "bg-slate-400"
          }`}>
            1
          </span>
          User Details
        </button>
        <div className="h-px w-12 bg-slate-300" />
        <button
          type="button"
          disabled={!shippingName || !shippingAddress || !shippingCity || !shippingZip}
          onClick={() => setActiveStep(2)}
          className={`flex items-center gap-2 text-sm font-bold transition disabled:opacity-50 ${
            activeStep === 2 ? "text-emerald-700" : "text-slate-500 hover:text-slate-800"
          }`}
        >
          <span className={`grid h-6 w-6 place-items-center rounded-full text-xs text-white ${
            activeStep === 2 ? "bg-emerald-600" : "bg-slate-400"
          }`}>
            2
          </span>
          Payment Options
        </button>
      </div>

      <form onSubmit={handleSubmit} className="grid gap-6 lg:grid-cols-[1fr_22rem]">
        <div className="space-y-5">
          {/* Step 1: User Details Section */}
          <section className="rounded-2xl border border-slate-200 bg-white overflow-hidden shadow-sm">
            <div className="flex items-center justify-between border-b border-slate-100 bg-slate-50/50 px-5 py-4">
              <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <span className="text-emerald-600 text-lg">👤</span>
                Step 1: User Details
              </h2>
              {activeStep === 2 && (
                <button
                  type="button"
                  onClick={() => setActiveStep(1)}
                  className="text-xs font-semibold text-emerald-700 hover:underline"
                >
                  ✏️ Edit
                </button>
              )}
            </div>

            {activeStep === 1 ? (
              <div className="p-5 space-y-4 animate-fade-in-up">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="sm:col-span-2">
                    <Field label="Full name">
                      <input
                        required
                        value={shippingName}
                        onChange={(e) => setShippingName(e.target.value)}
                        className={inputClass}
                        placeholder="Your full name"
                      />
                    </Field>
                  </div>
                  <div className="sm:col-span-2">
                    <Field label="Street address">
                      <input
                        required
                        value={shippingAddress}
                        onChange={(e) => setShippingAddress(e.target.value)}
                        className={inputClass}
                        placeholder="Flat / House no, street name"
                      />
                    </Field>
                  </div>
                  <Field label="City">
                    <input
                      required
                      value={shippingCity}
                      onChange={(e) => setShippingCity(e.target.value)}
                      className={inputClass}
                      placeholder="e.g. Bengaluru"
                    />
                  </Field>
                  <Field label="PIN code">
                    <input
                      required
                      value={shippingZip}
                      onChange={(e) => setShippingZip(e.target.value)}
                      className={inputClass}
                      placeholder="560001"
                      inputMode="numeric"
                    />
                  </Field>
                </div>

                <div className="pt-2 border-t border-slate-100 flex justify-end">
                  <button
                    type="button"
                    onClick={handleProceedToPayment}
                    className="rounded-xl bg-emerald-600 px-5 py-2.5 text-sm font-bold text-white shadow-sm transition hover:bg-emerald-700 active:scale-95"
                  >
                    Proceed to Payment Options →
                  </button>
                </div>
              </div>
            ) : (
              <div className="p-5 text-sm text-slate-700 bg-emerald-50/20">
                <p className="font-bold text-slate-900">{shippingName}</p>
                <p className="mt-1">{shippingAddress}</p>
                <p>{shippingCity} - {shippingZip}</p>
              </div>
            )}
          </section>

          {/* Step 2: Payment Section */}
          <section className={`rounded-2xl border bg-white overflow-hidden shadow-sm transition-opacity duration-200 ${
            activeStep === 2 ? "border-slate-200 opacity-100" : "border-slate-100 opacity-60 pointer-events-none"
          }`}>
            <div className="border-b border-slate-100 bg-slate-50/50 px-5 py-4">
              <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <span className="text-emerald-600 text-lg">💳</span>
                Step 2: Payment Method
              </h2>
            </div>

            {activeStep === 2 && (
              <div className="p-5 space-y-4 animate-fade-in-up">
                <div className="grid grid-cols-3 gap-3">
                  {[
                    { id: "card", label: "💳 Card" },
                    { id: "upi", label: "📱 UPI" },
                    { id: "cod", label: "💵 Cash on Delivery" },
                  ].map((opt) => (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => setPaymentMethod(opt.id)}
                      className={`rounded-xl border px-3 py-3 text-sm font-bold transition flex flex-col items-center justify-center gap-2 ${
                        paymentMethod === opt.id
                          ? "border-emerald-600 bg-emerald-50 text-emerald-700 ring-2 ring-emerald-600"
                          : "border-slate-200 text-slate-600 hover:bg-slate-50"
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
                <p className="text-xs text-slate-400">
                  ⚡ Safe and secure checkouts. No actual monetary transaction takes place in demo mode.
                </p>

                <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                  <button
                    type="button"
                    onClick={() => setActiveStep(1)}
                    className="text-sm font-semibold text-slate-500 hover:text-slate-800"
                  >
                    ← Back to Shipping
                  </button>
                  <button
                    type="submit"
                    disabled={loading}
                    className="rounded-xl bg-emerald-600 px-5 py-2.5 text-sm font-bold text-white shadow-sm transition hover:bg-emerald-700 disabled:opacity-60"
                  >
                    {loading ? "Placing Order…" : "Confirm & Place Order"}
                  </button>
                </div>
              </div>
            )}
          </section>
        </div>

        {/* Order Summary Sidebar */}
        <aside className="h-fit rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
          <h2 className="text-lg font-bold text-slate-900">Order Summary</h2>
          <ul className="mt-4 max-h-64 space-y-3 overflow-auto pr-1">
            {items.map(({ product, quantity }) => (
              <li key={product.id} className="flex items-center gap-3 text-sm">
                <span className="grid h-9 w-9 place-items-center rounded-lg bg-emerald-50 text-xl">
                  {product.emoji}
                </span>
                <span className="min-w-0 flex-1 truncate text-slate-700">
                  {product.name}
                  <span className="ml-1 text-slate-400">× {quantity}</span>
                </span>
                <span className="font-semibold text-slate-900">
                  {formatCurrency(product.price * quantity)}
                </span>
              </li>
            ))}
          </ul>
          <dl className="mt-4 space-y-2.5 border-t border-slate-200 pt-4 text-sm">
            <div className="flex justify-between">
              <dt className="text-slate-500">Subtotal</dt>
              <dd className="font-medium text-slate-900">{formatCurrency(subtotal)}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-slate-500">Shipping</dt>
              <dd className="font-medium text-slate-900">
                {shipping === 0 ? "Free" : formatCurrency(shipping)}
              </dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-slate-500">GST (5%)</dt>
              <dd className="font-medium text-slate-900">{formatCurrency(tax)}</dd>
            </div>
            <div className="flex justify-between border-t border-slate-200 pt-3 text-base">
              <dt className="font-bold text-slate-900">Total</dt>
              <dd className="font-bold text-emerald-700">{formatCurrency(total)}</dd>
            </div>
          </dl>

          {error && (
            <div className="mt-4 rounded-lg bg-red-50 px-4 py-3 text-sm font-medium text-red-700 ring-1 ring-red-200">
              {error}
            </div>
          )}

          {activeStep === 1 ? (
            <button
              type="button"
              onClick={handleProceedToPayment}
              className="mt-5 w-full rounded-xl bg-emerald-600 px-4 py-3 text-sm font-bold text-white shadow-sm transition hover:bg-emerald-700"
            >
              Proceed to Payment
            </button>
          ) : (
            <button
              type="submit"
              disabled={loading}
              className="mt-5 w-full rounded-xl bg-emerald-600 px-4 py-3 text-sm font-bold text-white shadow-sm transition hover:bg-emerald-700 disabled:opacity-60"
            >
              {loading ? "Placing order…" : `Pay & Place Order · ${formatCurrency(total)}`}
            </button>
          )}
        </aside>
      </form>
    </div>
  );
}
