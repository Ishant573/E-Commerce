"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Field, inputClass } from "@/components/auth/Auth";
import type { Product } from "@/lib/types";

const EMOJI_CHOICES = [
  "🛒", "🍎", "🍌", "🍓", "🍊", "🥑", "🍇", "🍉", "🥦", "🥕",
  "🍅", "🥔", "🧅", "🫑", "🌽", "🥬", "🥒", "🥛", "🧀", "🥚",
  "🧈", "🍞", "🥖", "🥯", "🥐", "🍗", "🥩", "🐟", "🦐", "🧃",
  "☕", "💧", "🥤", "🍫", "🍪", "🍿", "🥨", "🍚", "🍝", "🫒",
  "🥜", "🍯", "🧂", "🧊", "🥥", "🍑", "🍐", "🫐", "🍍", "🥭",
];

export function ProductForm({
  product,
  categories,
}: {
  product?: Product;
  categories: string[];
}) {
  const router = useRouter();
  const isEdit = Boolean(product);

  const [name, setName] = useState(product?.name ?? "");
  const [description, setDescription] = useState(product?.description ?? "");
  const [price, setPrice] = useState(product ? String(product.price) : "");
  const [emoji, setEmoji] = useState(product?.emoji ?? "🛒");
  const [unit, setUnit] = useState(product?.unit ?? "each");
  const [category, setCategory] = useState(product?.category ?? "");
  const [stock, setStock] = useState(product ? String(product.stock) : "0");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);

    const payload = {
      name,
      description,
      price: Number(price),
      emoji,
      unit,
      category: category.trim(),
      stock: Number(stock),
    };

    try {
      const url = isEdit ? `/api/products/${product!.id}` : "/api/products";
      const method = isEdit ? "PUT" : "POST";
      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Could not save product");
        setLoading(false);
        return;
      }
      router.push("/admin/products");
      router.refresh();
    } catch {
      setError("Something went wrong. Please try again.");
      setLoading(false);
    }
  }

  return (
    <div className="mx-auto max-w-2xl">
      <div className="mb-4">
        <Link
          href="/admin/products"
          className="text-sm font-medium text-slate-500 hover:text-emerald-700"
        >
          ← Back to products
        </Link>
      </div>

      <form
        onSubmit={handleSubmit}
        className="space-y-5 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm"
      >
        <h1 className="text-xl font-bold text-slate-900">
          {isEdit ? "Edit product" : "New product"}
        </h1>

        {error && (
          <div className="rounded-lg bg-red-50 px-4 py-3 text-sm font-medium text-red-700 ring-1 ring-red-200">
            {error}
          </div>
        )}

        <div className="flex items-center gap-4">
          <div className="grid h-20 w-20 flex-shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-emerald-50 to-lime-50 text-5xl">
            {emoji}
          </div>
          <div className="flex-1">
            <span className="mb-1.5 block text-sm font-medium text-slate-700">
              Icon
            </span>
            <div className="flex flex-wrap gap-1">
              {EMOJI_CHOICES.map((e) => (
                <button
                  key={e}
                  type="button"
                  onClick={() => setEmoji(e)}
                  className={`grid h-8 w-8 place-items-center rounded-md text-lg transition ${
                    emoji === e
                      ? "bg-emerald-600 ring-2 ring-emerald-300"
                      : "bg-slate-100 hover:bg-slate-200"
                  }`}
                >
                  {e}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <div className="sm:col-span-2">
            <Field label="Name">
              <input
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className={inputClass}
                placeholder="Organic Bananas"
              />
            </Field>
          </div>
          <div className="sm:col-span-2">
            <Field label="Description">
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={2}
                className={inputClass}
                placeholder="Short, tasty description…"
              />
            </Field>
          </div>
          <Field label="Price (₹)">
            <input
              required
              type="number"
              step="0.01"
              min="0"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              className={inputClass}
              placeholder="1.99"
            />
          </Field>
          <Field label="Unit">
            <input
              required
              value={unit}
              onChange={(e) => setUnit(e.target.value)}
              className={inputClass}
              placeholder="lb, each, pack…"
            />
          </Field>
          <Field label="Category">
            <input
              required
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              list="categories"
              className={inputClass}
              placeholder="Fruits"
            />
            <datalist id="categories">
              {categories.map((c) => (
                <option key={c} value={c} />
              ))}
            </datalist>
          </Field>
          <Field label="Stock quantity">
            <input
              required
              type="number"
              min="0"
              value={stock}
              onChange={(e) => setStock(e.target.value)}
              className={inputClass}
            />
          </Field>
        </div>

        <div className="flex gap-3 pt-2">
          <button
            type="submit"
            disabled={loading}
            className="flex-1 rounded-xl bg-emerald-600 px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-emerald-700 disabled:opacity-60"
          >
            {loading ? "Saving…" : isEdit ? "Save changes" : "Create product"}
          </button>
          <Link
            href="/admin/products"
            className="rounded-xl border border-slate-300 px-4 py-2.5 text-center text-sm font-medium text-slate-600 transition hover:bg-slate-50"
          >
            Cancel
          </Link>
        </div>
      </form>
    </div>
  );
}
