"use client";

import { useState } from "react";
import Link from "next/link";
import type { Product } from "@/lib/types";
import { useCart } from "@/components/CartProvider";
import { formatCurrency } from "@/lib/format";

const GRADIENTS = [
  "from-rose-100 to-orange-100",
  "from-lime-100 to-emerald-100",
  "from-sky-100 to-indigo-100",
  "from-amber-100 to-yellow-100",
  "from-fuchsia-100 to-pink-100",
  "from-teal-100 to-cyan-100",
];

function gradientFor(id: number) {
  return GRADIENTS[id % GRADIENTS.length];
}

export function ProductCard({ product }: { product: Product }) {
  const { add } = useCart();
  const [added, setAdded] = useState(false);
  const outOfStock = product.stock <= 0;

  function handleAdd() {
    if (outOfStock) return;
    add(product);
    setAdded(true);
    window.setTimeout(() => setAdded(false), 1200);
  }

  return (
    <div className="group flex flex-col overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm transition hover:-translate-y-0.5 hover:shadow-md">
      <div
        className={`relative flex aspect-[4/3] items-center justify-center bg-gradient-to-br ${gradientFor(
          product.id,
        )}`}
      >
        <span className="text-6xl drop-shadow-sm transition group-hover:scale-110">
          {product.emoji}
        </span>
        <span className="absolute left-3 top-3 rounded-full bg-white/80 px-2.5 py-1 text-[11px] font-semibold uppercase tracking-wide text-slate-600 backdrop-blur">
          {product.category}
        </span>
        {outOfStock && (
          <span className="absolute right-3 top-3 rounded-full bg-slate-900/80 px-2.5 py-1 text-[11px] font-bold text-white">
            Sold out
          </span>
        )}
      </div>

      <div className="flex flex-1 flex-col p-4">
        <h3 className="text-base font-semibold text-slate-900">{product.name}</h3>
        {product.description && (
          <p className="mt-1 line-clamp-2 text-sm text-slate-500">
            {product.description}
          </p>
        )}

        <div className="mt-3 flex items-end justify-between">
          <div>
            <p className="text-lg font-bold text-emerald-700">
              {formatCurrency(product.price)}
            </p>
            <p className="text-xs text-slate-400">per {product.unit}</p>
          </div>
          {!outOfStock && (
            <p className="text-[11px] font-medium text-slate-400">
              {product.stock} in stock
            </p>
          )}
        </div>

        <button
          type="button"
          onClick={handleAdd}
          disabled={outOfStock}
          className={`mt-4 w-full rounded-xl px-4 py-2.5 text-sm font-semibold transition ${
            outOfStock
              ? "cursor-not-allowed bg-slate-100 text-slate-400"
              : added
                ? "bg-emerald-600 text-white"
                : "bg-emerald-600 text-white hover:bg-emerald-700 active:scale-[0.98]"
          }`}
        >
          {outOfStock ? "Unavailable" : added ? "✓ Added to cart" : "Add to cart"}
        </button>
      </div>
    </div>
  );
}

export function ProductGrid({ products }: { products: Product[] }) {
  if (products.length === 0) {
    return (
      <div className="rounded-2xl border border-dashed border-slate-300 bg-white/60 p-12 text-center">
        <p className="text-4xl">🔍</p>
        <p className="mt-3 text-lg font-semibold text-slate-700">
          No products found
        </p>
        <p className="mt-1 text-sm text-slate-500">
          Try a different search or category.
        </p>
        <Link
          href="/"
          className="mt-4 inline-block rounded-lg bg-emerald-600 px-4 py-2 text-sm font-semibold text-white hover:bg-emerald-700"
        >
          Clear filters
        </Link>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
      {products.map((p) => (
        <ProductCard key={p.id} product={p} />
      ))}
    </div>
  );
}
