export function StatusBadge({
  status,
  styles,
}: {
  status: string;
  styles: Record<string, string>;
}) {
  const cls = styles[status] ?? "bg-slate-100 text-slate-700";
  return (
    <span
      className={`rounded-full px-2.5 py-1 text-xs font-semibold capitalize ${cls}`}
    >
      {status}
    </span>
  );
}
