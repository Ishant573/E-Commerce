import Link from "next/link";

export function SuccessBanner({ orderId }: { orderId: number }) {
  return (
    <div className="animate-fade-in-up flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-emerald-200 bg-emerald-50 px-5 py-4">
      <div className="flex items-center gap-3">
        <span className="grid h-10 w-10 place-items-center rounded-full bg-emerald-600 text-xl text-white">
          ✓
        </span>
        <div>
          <p className="font-bold text-emerald-900">
            Thank you! Your order #{orderId} was placed.
          </p>
          <p className="text-sm text-emerald-700">
            We&apos;ll send updates as it&apos; processed.
          </p>
        </div>
      </div>
      <Link
        href="/"
        className="rounded-lg bg-emerald-600 px-4 py-2 text-sm font-semibold text-white transition hover:bg-emerald-700"
      >
        Continue shopping
      </Link>
    </div>
  );
}
