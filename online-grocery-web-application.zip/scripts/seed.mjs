// Seed script for FreshCart — run with: node scripts/seed.mjs
// Uses the same scrypt password format as src/lib/password.ts
// All prices are in Indian Rupees (₹).
import pg from "pg";
import { scryptSync, randomBytes } from "crypto";

const DATABASE_URL =
  process.env.DATABASE_URL ||
  "postgresql://postgres:postgres@127.0.0.1:5432/app_db";

const KEY_LENGTH = 64;

function hashPassword(password) {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, KEY_LENGTH).toString("hex");
  return `${salt}:${hash}`;
}

// [name, description, price(₹), emoji, unit, category, stock]
const PRODUCTS = [
  // Fruits
  ["Organic Apples", "Crisp and sweet Shimla apples", 240, "🍎", "kg", "Fruits", 48],
  ["Bananas", "Ripe, ready-to-eat bananas", 59, "🍌", "dozen", "Fruits", 120],
  ["Strawberries", "Fresh hand-picked strawberries", 349, "🍓", "pack", "Fruits", 30],
  ["Navel Oranges", "Juicy Nagpur oranges", 159, "🍊", "kg", "Fruits", 40],
  ["Hass Avocados", "Ripe Hass avocados", 120, "🥑", "each", "Fruits", 55],
  ["Red Grapes", "Sweet seedless grapes", 320, "🍇", "kg", "Fruits", 24],
  ["Blueberries", "Plump antioxidant-rich blueberries", 399, "🫐", "pack", "Fruits", 18],
  ["Alphonso Mangoes", "Sweet Ratnagiri Alphonso mangoes", 599, "🥭", "kg", "Fruits", 26],
  ["Watermelon", "Fresh chilled watermelon", 89, "🍉", "each", "Fruits", 33],
  ["Pomegranate", "Juicy red pomegranate", 180, "🍎", "kg", "Fruits", 21],

  // Vegetables
  ["Carrots", "Crunchy farm carrots", 49, "🥕", "kg", "Vegetables", 90],
  ["Broccoli", "Fresh green broccoli crowns", 159, "🥦", "kg", "Vegetables", 36],
  ["Tomatoes", "Farm-fresh tomatoes", 39, "🍅", "kg", "Vegetables", 42],
  ["Potatoes", "All-purpose potatoes", 35, "🥔", "kg", "Vegetables", 150],
  ["Onions", "Pink cooking onions", 45, "🧅", "kg", "Vegetables", 80],
  ["Bell Peppers", "Colorful sweet capsicum", 145, "🫑", "kg", "Vegetables", 28],
  ["Sweet Corn", "Fresh ears of sweet corn", 55, "🌽", "each", "Vegetables", 4],
  ["Spinach (Palak)", "Fresh green palak leaves", 35, "🥬", "bunch", "Vegetables", 22],
  ["Green Chillies", "Spicy fresh green chillies", 25, "🌶️", "pack", "Vegetables", 60],
  ["Ginger", "Fresh aromatic ginger", 89, "🫚", "kg", "Vegetables", 31],

  // Dairy & Eggs
  ["Toned Milk", "Fresh Amul toned milk, 1 litre", 68, "🥛", "litre", "Dairy & Eggs", 60],
  ["Farm Eggs", "Farm-fresh brown eggs, dozen", 99, "🥚", "dozen", "Dairy & Eggs", 75],
  ["Paneer", "Soft fresh malai paneer", 320, "🧀", "pack", "Dairy & Eggs", 33],
  ["Butter", "Creamy salted butter", 260, "🧈", "pack", "Dairy & Eggs", 40],
  ["Greek Yogurt", "Thick protein-rich curd", 65, "🥣", "each", "Dairy & Eggs", 64],

  // Bakery
  ["Sliced Bread", "Soft whole-wheat sliced bread", 45, "🍞", "loaf", "Bakery", 50],
  ["Bun Pack", "Freshly baked burger buns", 65, "🥯", "pack", "Bakery", 26],
  ["Butter Croissant", "Flaky butter croissants", 99, "🥐", "each", "Bakery", 5],
  ["Pav", "Soft Mumbai pav buns", 40, "🍞", "pack", "Bakery", 0],

  // Meat & Seafood
  ["Chicken Breast", "Boneless skinless chicken breast", 320, "🍗", "kg", "Meat & Seafood", 38],
  ["Ground Chicken", "Fresh chicken mince", 280, "🍗", "kg", "Meat & Seafood", 30],
  ["Rohu Fish", "Fresh river rohu fish", 449, "🐟", "kg", "Meat & Seafood", 15],
  ["Prawns", "Peeled deveined fresh prawns", 699, "🦐", "kg", "Meat & Seafood", 3],

  // Beverages
  ["Orange Juice", "100% pure squeezed juice", 199, "🧃", "each", "Beverages", 44],
  ["Filter Coffee", "South Indian filter coffee powder", 360, "☕", "pack", "Beverages", 27],
  ["Sparkling Water", "Naturally flavoured sparkling water", 89, "💧", "each", "Beverages", 96],
  ["Masala Chai Mix", "Refreshing masala chai mix", 149, "🫖", "pack", "Beverages", 52],

  // Snacks
  ["Dark Chocolate", "70% cacao dark chocolate bar", 175, "🍫", "bar", "Snacks", 70],
  ["Masala Popcorn", "Buttery masala microwave popcorn", 99, "🍿", "pack", "Snacks", 48],
  ["Bourbon Biscuits", "Chocolate cream biscuits", 45, "🍪", "pack", "Snacks", 39],
  ["Namkeen", "Crunchy spiced bhujia namkeen", 85, "🥨", "pack", "Snacks", 41],

  // Pantry
  ["Basmati Rice", "Premium long-grain basmati rice", 220, "🍚", "kg", "Pantry", 60],
  ["Durum Pasta", "Classic durum wheat spaghetti", 89, "🍝", "pack", "Pantry", 88],
  ["Mustard Oil", "Cold-pressed mustard oil", 180, "🫒", "litre", "Pantry", 35],
  ["Besan", "Fine gram flour (besan)", 75, "🌾", "kg", "Pantry", 47],
  ["Pure Honey", "Raw wildflower honey", 325, "🍯", "jar", "Pantry", 29],
  ["Toor Dal", "Premium unpolished toor dal", 165, "🫘", "kg", "Pantry", 53],
];

async function main() {
  const pool = new pg.Pool({ connectionString: DATABASE_URL });
  const client = await pool.connect();
  try {
    console.log("🌱 Seeding FreshCart database…");

    await client.query("TRUNCATE order_items, orders, sessions, products, users RESTART IDENTITY CASCADE");

    // Users
    const adminHash = hashPassword("admin123");
    const userHash = hashPassword("demo123");

    const userInserts = [
      ["FreshCart Admin", "admin@grocery.com", adminHash, "admin"],
      ["Demo Shopper", "demo@grocery.com", userHash, "user"],
    ];
    for (const [name, email, hash, role] of userInserts) {
      await client.query(
        `INSERT INTO users (name, email, password_hash, role) VALUES ($1, $2, $3, $4)`,
        [name, email, hash, role],
      );
    }
    console.log(`   ✓ ${userInserts.length} users`);

    // Products
    let count = 0;
    for (const [name, desc, price, emoji, unit, category, stock] of PRODUCTS) {
      await client.query(
        `INSERT INTO products (name, description, price, emoji, unit, category, stock)
         VALUES ($1, $2, $3, $4, $5, $6, $7)`,
        [name, desc, price, emoji, unit, category, stock],
      );
      count++;
    }
    console.log(`   ✓ ${count} products`);

    console.log("✅ Seed complete.");
  } finally {
    client.release();
    await pool.end();
  }
}

main().catch((err) => {
  console.error("Seed failed:", err);
  process.exit(1);
});
